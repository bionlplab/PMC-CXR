# RadText Developer Guide

## Create this documentation

```bash
$ pip install Sphinx sphinx_rtd_theme recommonmark
$ cd docs
$ make html
```

## Testing the code

```bash
$ python -m pytest tests
```